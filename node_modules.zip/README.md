![Logo](https://cdn.discordapp.com/attachments/547571609708527637/910696439246639164/unknown.png)
# Raburadio-Backend
This is the backend repository for Raburadio, a website to archive all the songs in the Love Live! franchise.
A re-write of the PHP-based [LLArchive](https://github.com/HuzzNZ/LLArchive). For the frontend, please see [Raburadio](https://github.com/HuzzNZ/Raburadio).
## Frameworks/Languages used
Node.js, Apollo, GraphQL, Mongoose, MongoDB
## License
This website is open-source under the Apache 2.0 License.
