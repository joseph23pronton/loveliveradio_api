// config.js
const ENV = {
    mongoURL: "mongodb+srv://raburadio:ganbaruby23@killerspit23db.ybnim.gcp.mongodb.net/?retryWrites=true&w=majority",
  };
  
  export { ENV };
  // config.js
const PORT = 3001; // Replace 3000 with your desired port number

export { PORT };
  